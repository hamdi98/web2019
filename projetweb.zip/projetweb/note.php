<?PHP
class Note{
	private $idnote;
	private $note;
	
	
	function __construct($idnote,$note){
		
		$this->idnote=$idnote;
		$this->note=$note;
		
	}
	
	function getidnote(){
		return $this->idnote;
	}
	function getnote(){
		return $this->note;
	}
	
	
	function setidnote($idnote){
		$this->idnote=$idnote;
	}
	function setnote($note){
		$this->note;
	}
	
		
}

?>