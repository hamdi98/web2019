<?PHP
include "note.php";
include "noteC.php";

if (isset($_POST['idnote']) and isset($_POST['note'])  ){
$note1=new note($_POST['idnote'],$_POST['note']);
//Partie2
/*
var_dump($employe1);
}
*/
//Partie3
$note1C=new NoteC();
$note1C->ajouterNote($note1);
header('Location: afficherNote.php');
	
}else{
	echo "vérifier les champs";
}
//*/

?>