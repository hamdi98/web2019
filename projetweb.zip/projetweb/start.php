<?PHP
include "../entities/reclamation.php";
include "../core/reclamationC.php";
$reclamation=new Reclamation(75757575,'BEN Ahmed','Salah');
$reclamationC=new ReclamationC();
$reclamationC->afficherReclamation($employe);
echo "****************";
echo "<br>";
echo "id:".$reclamation->getId();
echo "<br>";
echo "nom:".$employe->getNom();
echo "<br>";
echo "prenom:".$employe->getPrenom();
echo "<br>";




?>