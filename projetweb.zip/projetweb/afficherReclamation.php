<?PHP
include "reclamationC.php";
$reclamation1C=new ReclamationC();
$listeReclamations=$reclamation1C->afficherReclamations();

//var_dump($listeEmployes->fetchAll());
?>
<table border="1">
<tr>
<td>Name</td>
<td>Email</td>
<td>Subject</td>
<td>Message</td>
<td>supprimer</td>
<td>modifier</td>
</tr>

<?PHP
foreach($listeReclamations as $row){
	?>
	<tr>
	<td><?PHP echo $row['name']; ?></td>
	<td><?PHP echo $row['email']; ?></td>
	<td><?PHP echo $row['subject']; ?></td>
	<td><?PHP echo $row['message']; ?></td>
	
	<td><form method="POST" action="supprimerReclamation.php">
	<input type="submit" name="supprimer" value="supprimer">
	<input type="hidden" value="<?PHP echo $row['name']; ?>" name="name">
	</form>
	</td>
	<td><a href="modifierReclamation.php?name=<?PHP echo $row['name']; ?>">
	Modifier</a></td>
	</tr>
	<?PHP
}
?>
</table>


