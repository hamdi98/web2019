<?PHP
include "reclamation.php";
include "reclamationC.php";

if (isset($_POST['name']) and isset($_POST['email']) and isset($_POST['subject']) and isset($_POST['message']) ){
$reclamation1=new reclamation($_POST['name'],$_POST['email'],$_POST['subject'],$_POST['message']);
//Partie2
/*
var_dump($employe1);
}
*/
//Partie3
$reclamation1C=new ReclamationC();
$reclamation1C->ajouterReclamation($reclamation1);
header('Location: afficherReclamation.php');
	
}else{
	echo "vérifier les champs";
}
//*/

?>