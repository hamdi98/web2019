<?PHP
require "reclamation.php";
require "reclamationC.php";
require_once 'lib/phpmailer/PHPMailerAutoLoad.php';
//$name=$_GET["name"];
if(empty($_POST['name']))
{
	echo "<script type='text/javascript'>";
echo "alert('something wrong!');";
echo "</script>";
exit;
}
else
{

//$ec= new ReclamationC();
//$ec->confirmer($name);
//$result=$ec->recupererEmail($id);

$db= mysqli_connect("localhost","root","","projetweb");
$sql = "SELECT email FROM reclamation  where name='$name' ";
$result = mysqli_query($db,$sql);
$count = mysqli_num_rows($result);
$row_data = mysqli_fetch_array($result);
$to =$row_data['email'];
$subject = "Reclamation daridesign";
$messageBody ="Your request RendezVous is confirmed by daridesign.";
if( $count ==0){
        echo"Jointurek ghalta";
        return;
    }
	else 
	{
		$mail = new PHPMailer();
        $mail->IsSMTP();
        $mail->SMTPAuth = true; // authentication enabled
        $mail->IsHTML(true); 
        $mail->SMTPSecure = 'ssl';//turn on to send html email
        // $mail->Host = "ssl://smtp.zoho.com";
        $mail->Host = "ssl://smtp.gmail.com"; 
        $mail->Port = 465;
        $mail->Username = "aymen.smati@esprit.tn";
        $mail->Password = "robben2011";
        $mail->SetFrom("aymen.smati@esprit.tn", "daridesign");
        $mail->Subject = $subject;

        $mail->Body = $messageBody;
        $mail->AddAddress($to);
		
		if(!$mail->send()) {
           echo "Mailer Error: " . $mail->ErrorInfo;
       } 
       else {
           echo "Message has been sent successfully";
      }
	}


header('Location: displayRdv.php'); 
}

?>

