<HTML>
<head>
</head>
<body>
<?PHP
include "reclamation.php";
include "reclamationC.php";
if (isset($_GET['name'])){
	$reclamationC=new ReclamationC();
    $result=$reclamationC->recupererReclamation($_GET['name']);
	foreach($result as $row){
		$name=$row['name'];
		$email=$row['email'];
		$subject=$row['subject'];
		$message=$row['message'];

?>
<form method="POST">
<caption>Modifier Reclamation</caption>

Name
<input type="text" name="name" value="<?PHP echo $name ?>">


Email
<input type="text" name="email" value="<?PHP echo $email ?>">


Subject
<input type="text" name="subject" value="<?PHP echo $subject ?>">


Message
<input type="text" name="message" value="<?PHP echo $message ?>">



<input type="submit" name="modifier" value="modifier">



<input type="hidden" name="name_ini" value="<?PHP echo $_GET['name'];?>">

</form>
<?PHP
	}
}
if (isset($_POST['modifier'])){
	$reclamation=new reclamation($_POST['name'],$_POST['email'],$_POST['subject'],$_POST['message']);
	$reclamationC->modifierReclamation($reclamation,$_POST['name_ini']);
	echo $_POST['name_ini'];
	header('Location: afficherReclamation.php');
}
?>
</body>
</HTMl>