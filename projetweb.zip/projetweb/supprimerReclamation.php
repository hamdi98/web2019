<?PHP
include "reclamationC.php";
$reclamationC=new ReclamationC();
if (isset($_POST["name"])){
	$reclamationC->supprimerReclamation($_POST["name"]);
	header('Location: afficherReclamation.php');
}

?>