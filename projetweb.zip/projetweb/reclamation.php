<?PHP
class Reclamation{
	private $name;
	private $email;
	private $subject;
	private $message;
	
	function __construct($name,$email,$subject,$message){
		
		$this->name=$name;
		$this->email=$email;
		$this->subject=$subject;
		$this->message=$message;
	}
	
	function getname(){
		return $this->name;
	}
	function getemail(){
		return $this->email;
	}
	function getsubject(){
		return $this->subject;
	}
	function getmessage(){
		return $this->message;

	}
	
	function setname($name){
		$this->name=$name;
	}
	function setemail($email){
		$this->email;
	}
	function setsubject($subject){
		$this->subject=$subject;
	}
		function setmessage($message){

			$this->message=$message;
		}
}

?>