<?PHP
include "config.php";
class ReclamationC {
function afficherReclamation ($reclamation){
		echo "Name: ".$reclamation->getname()."<br>";
		echo "Email: ".$reclamation->getemail()."<br>";
		echo "Subject: ".$reclamation->getsubject()."<br>";
		echo "message: ".$reclamation->getmessage()."<br>";
	}
	
	function ajouterReclamation($reclamation){
		$sql="insert into reclamation (name,email,subject,message) values (:name, :email,:subject,:message)";
		$db = config::getConnexion();
		try{
        $req=$db->prepare($sql);
        $name=$reclamation->getname();
        $email=$reclamation->getemail();
        $subject=$reclamation->getsubject();
        $message=$reclamation->getmessage();
		$req->bindValue(':name',$name);
		$req->bindValue(':email',$email);
		$req->bindValue(':subject',$subject);
	    $req->bindValue(':message',$message);
		
            $req->execute();
           header("Location:redirect.php");
exit();

        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
		
	}
	
	function afficherReclamations(){
		//$sql="SElECT * From employe e inner join formationphp.employe a on e.cin= a.cin";
		$sql="SElECT * From reclamation";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }	
	}
	function supprimerReclamation($name){
		$sql="DELETE FROM reclamation where name= :name";
		$db = config::getConnexion();
        $req=$db->prepare($sql);
		$req->bindValue(':name',$name);
		try{
            $req->execute();
header("Location:indextemp.php");
exit();
 }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	function modifierReclamation($reclamation,$name){
		$sql="UPDATE reclamation SET name=:namee, email=:email, subject=:subject, message=:messagee WHERE name=:name";
		
		$db = config::getConnexion();
		//$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
try{		
        $req=$db->prepare($sql);
		$namee=$reclamation->getname();
        $nom=$reclamation->getemail();
        $subjectt=$reclamation->getsubject();
		$messagee=$reclamation->getmessage();
        
		$datas = array(':namee'=>$namee, ':name'=>$name, ':email'=>$email,':subject'=>$subject,':messagee'=>$messagee);
		$req->bindValue(':namee',$namee);
		$req->bindValue(':name',$name);
		$req->bindValue(':email',$email);
		$req->bindValue(':subject',$subject);
		   $req->bindValue(':messagee',$messagee);
		
		
            $s=$req->execute();
			
           // header('Location: index.php');
        }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
   echo " Les datas : " ;
  print_r($datas);
        }
		
	}
	function recupererReclamation($name){
		$sql="SELECT * from reclamation where name=$name";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	
	function rechercherListeReclamation($subjectt){
		$sql="SELECT * from reclamation where subject=$subjectt";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
}

?>