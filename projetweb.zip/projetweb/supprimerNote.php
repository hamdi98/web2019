<?PHP
include "noteC.php";
$noteC=new NoteC();
if (isset($_POST["idnote"])){
	$noteC->supprimerNote($_POST["idnote"]);
	header('Location: afficherNote.php');
}

?>