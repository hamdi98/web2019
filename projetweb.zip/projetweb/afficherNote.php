<?PHP
include "noteC.php";
$note1C=new NoteC();
$listeNotes=$note1C->afficherNotes();

//var_dump($listeEmployes->fetchAll());
?>
<table border="1">
<tr>
<td>Idnote</td>
<td>Note</td>


<td>supprimer</td>
<td>modifier</td>
</tr>

<?PHP
foreach($listeNotes as $row){
	?>
	<tr>
	<td><?PHP echo $row['idnote']; ?></td>
	<td><?PHP echo $row['note']; ?></td>

	
	
	<td><form method="POST" action="supprimerNote.php">
	<input type="submit" name="supprimer" value="supprimer">
	<input type="hidden" value="<?PHP echo $row['idnote']; ?>" idnote="idnote">
	</form>
	</td>
	<td><a href="modifierNote.php?idnote=<?PHP echo $row['idnote']; ?>">
	Modifier</a></td>
	</tr>
	<?PHP
}
?>
</table>


