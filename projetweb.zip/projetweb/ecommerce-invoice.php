<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from jthemes.org/demo-admin/minton/ecommerce-invoice.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 28 Feb 2019 23:43:03 GMT -->
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<!-- Tell the browser to be responsive to screen width -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Admin Mintone">
<meta name="author" content="Admin Mintone">
<!-- Favicon icon -->
<link rel="icon" type="image/png" sizes="16x16" href="assets/imgs/favicon.png">
<title>Admin Mintone - Bootstrap 4 Admin Template</title>
<!-- Bootstrap Core CSS -->
<link href="plugins/vendors/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="plugins/vendors/perfect-scrollbar/css/perfect-scrollbar.css" rel="stylesheet">
<!-- This page CSS -->
<!-- Custom CSS -->
<link href="assets/css/style.css" rel="stylesheet">
<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>
<body class="fix-header fix-sidebar card-no-border">
<!-- ============================================================== -->
<!-- Preloader - style you can find in spinners.css -->
<!-- ============================================================== -->
<div class="preloader">
  <div class="loader">
    <div class="loader__figure"></div>
    <p class="loader__label">Admin Mintone</p>
  </div>
</div>
<!-- ============================================================== -->
<!-- Main wrapper - style you can find in pages.scss -->
<!-- ============================================================== -->
<div id="main-wrapper">
  <!-- ============================================================== -->
  <!-- Container1140px -->
  <!-- ============================================================== -->
  <!-- ============================================================== -->
  <!-- Topbar header - style you can find in pages.scss -->
  <!-- ============================================================== -->
  <header class="topbar">
    <div Class="container">
      <nav class="navbar top-navbar navbar-expand-md navbar-light">
        <!-- ============================================================== -->
        <!-- Logo -->
        <!-- ============================================================== -->
        <div class="navbar-header"> <a class="navbar-brand" href="index.html">
          <!-- Logo icon -->
          <b>
          <!--You can put here icon as well // <i class="wi wi-sunset"></i> //-->
          <!-- Dark Logo icon -->
          <img src="assets/imgs/logo-icon.png" alt="homepage" class="dark-logo" />
          <!-- Light Logo icon -->
          <img src="assets/imgs/logo-light-icon.png" alt="homepage" class="light-logo" /> </b>
          <!--End Logo icon -->
          <!-- Logo text -->
          <span>
          <!-- dark Logo text -->
          <img src="assets/imgs/logo-text.png" alt="homepage" class="dark-logo dark-logo2" />
          <!-- Light Logo text -->
          <img src="assets/imgs/logo-light-text.png" class="light-logo" alt="homepage" /></span> </a> </div>
        <!-- ============================================================== -->
        <!-- End Logo -->
        <!-- ============================================================== -->
        <div class="top-bar-main">
          <!-- ============================================================== -->
          <!-- toggle and nav items -->
          <!-- ============================================================== -->
          <div class="float-left">
            <ul class="navbar-nav">
              <li class="nav-item "><a class="nav-link navbar-toggler sidebartoggler waves-effect waves-dark float-right" href="javascript:void(0)"><span class="navbar-toggler-icon"></span></a></li>
              <!-- ============================================================== -->
              <!-- Search -->
              <!-- ============================================================== -->
              <li class="nav-item hidden-xs-down app-search">
                <input type="text" class="form-control float-left" placeholder="Type for search...">
              </li>
            </ul>
          </div>
          <!-- ============================================================== -->
          <!-- User profile and search -->
          <!-- ============================================================== -->
          <div class="float-right pr-3">
            <ul class="navbar-nav my-lg-0 float-right">
              <!-- ============================================================== -->
              <!-- Comment -->
              <!-- ============================================================== -->
              <li class="nav-item dropdown"> <a class="nav-link dropdown-toggle waves-effect waves-dark" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="mdi mdi-bell"></i>
                <div class="notify"> <span class="heartbit"></span> <span class="point"></span> </div>
                </a>
                <div class="dropdown-menu dropdown-menu-right mailbox animated fadeIn">
                  <ul>
                    <li>
                      <div class="drop-title">You have <span class="highlighted">3 new</span> Notifications</div>
                    </li>
                    <li>
                      <div class="message-center">
                        <!-- Message -->
                        <a href="#">
                        <div class="mail-content"> <i class="fas fa-envelope"></i> 2 new messages <span class="float-right text-light">15:07</span> </div>
                        </a>
                        <!-- Message -->
                        <!-- Message -->
                        <a href="#">
                        <div class="mail-content"> <i class="fas fa-comment"></i> 1 new comment <span class="float-right text-light">11.08.2018</span> </div>
                        </a>
                        <!-- Message -->
                        <a href="#">
                        <div class="mail-content"> <i class="fas fa-calendar-alt"></i> 2 Events Soon <span class="float-right text-light">10.08.2018</span> </div>
                        </a> </div>
                    </li>
                    <li> <a class="nav-link text-center" href="javascript:void(0);">See all notifications </a> </li>
                  </ul>
                </div>
              </li>
              <!-- ============================================================== -->
              <!-- End Comment -->
              <!-- ============================================================== -->
              <!-- ============================================================== -->
              <!-- Messages -->
              <!-- ============================================================== -->
              <li class="nav-item dropdown"> <a class="nav-link dropdown-toggle waves-effect waves-dark" href="#" id="2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="mdi mdi-message"></i>
                <div class="notify"> <span class="heartbit"></span> <span class="point"></span> </div>
                </a>
                <div class="dropdown-menu mailbox dropdown-menu-right animated fadeIn" aria-labelledby="2">
                  <ul>
                    <li>
                      <div class="drop-title">You have <span class="highlighted">7 new</span> messages</div>
                    </li>
                    <li>
                      <div class="message-center">
                        <!-- Message -->
                        <a href="#">
                        <div class="user-img"> <img src="assets/imgs/users/1.jpg" alt="user" class="img-circle"> <span class="profile-status online pull-right"></span> </div>
                        <div class="mail-content">
                          <div class="float-left">
                            <h5 class="mt-0 text-dark">Amanda Robertson</h5>
                            <span class="mail-desc text-light mt-1">Guterres was elec...</span> </div>
                          <span class="float-right text-light text-right">11:18 <span class="clearfix"></span> <span class="label label-rounded label-primary">1</span> </span> </div>
                        <div class="clearfix"></div>
                        </a>
                        <!-- Message -->
                        <a href="#">
                        <div class="user-img"> <img src="assets/imgs/users/img2.jpg" alt="user" class="img-circle"> <span class="profile-status online pull-right"></span> </div>
                        <div class="mail-content">
                          <div class="float-left">
                            <h5 class="mt-0 text-dark">Danny Donavan</h5>
                            <span class="mail-desc text-light mt-1">Guterres was elec...</span></div>
                          <div class="float-right text-light text-right">09.07.2018 <span class="clearfix"></span> <span class="label label-rounded label-primary">2</span> </div>
                        </div>
                        <div class="clearfix"></div>
                        </a>
                        <!-- Message -->
                        <a href="#">
                        <div class="user-img"> <img src="assets/imgs/users/1.jpg" alt="user" class="img-circle"> <span class="profile-status online pull-right"></span> </div>
                        <div class="mail-content">
                          <div class="float-left">
                            <h5 class="mt-0 text-dark">Frank Hendrics</h5>
                            <span class="mail-desc text-light mt-1">Guterres was elec...</span></div>
                          <div class="float-right text-light text-right">10.08.2018 <span class="clearfix"></span> <span class="label label-rounded label-primary">4</span> </div>
                        </div>
                        <div class="clearfix"></div>
                        </a> </div>
                    </li>
                    <li> <a class="nav-link text-center" href="javascript:void(0);">See all notifications </a> </li>
                  </ul>
                </div>
              </li>
              <!-- ============================================================== -->
              <!-- End Messages -->
              <!-- ============================================================== -->
              <!-- ============================================================== -->
              <!-- End mega menu -->
              <!-- ============================================================== -->
              <!-- ============================================================== -->
              <!-- Profile -->
              <!-- ============================================================== -->
              <li class="nav-item dropdown u-pro"> <a class="nav-link dropdown-toggle waves-effect waves-dark profile-pic" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img src="assets/imgs/users/user-50x50.jpg" alt="user" class="" /><span class="circle-status"></span></a>
                <div class="dropdown-menu dropdown-menu-right animated fadeIn">
                  <ul class="dropdown-user">
                    <li class="text-center">
                      <div class="dw-user-box">
                        <div class="u-img"><img src="assets/imgs/users/user-50x50.jpg" alt="user"></div>
                        <div class="clearfix"></div>
                        <div class="u-text">
                          <h4>Mason Vox</h4>
                          <p class="text-light"><span class="status-circle bg-success"></span>online <i class="fas fa-chevron-down small"></i></p>
                        </div>
                      </div>
                    </li>
                    <li role="separator" class="divider"></li>
                    <li><a href="#"><span class="status-circle bg-success"></span> online</a></li>
                    <li><a href="#"><span class="status-circle bg-warning"></span> away</a></li>
                    <li><a href="#"><span class="status-circle bg-danger"></span> not disturb</a></li>
                    <li><a href="#"><span class="status-circle bg-light"></span> offline</a></li>
                    <li role="separator" class="divider"></li>
                    <li><a href="#"><i class="fas fa-user mr-1"></i> My Profile</a></li>
                    <li><a href="#"><i class="fas fa-cog mr-1"></i> Settings</a></li>
                    <li role="separator" class="divider"></li>
                    <li><a href="#"><i class="fas fa-sign-in-alt mr-1"></i> Logout</a></li>
                  </ul>
                </div>
              </li>
            </ul>
          </div>
          <div class="clearfix"></div>
        </div>
      </nav>
    </div>
  </header>
  <!-- ============================================================== -->
  <!-- End Topbar header -->
  <!-- ============================================================== -->
  <!-- ============================================================== -->
  <!-- Left Sidebar - style you can find in sidebar.scss  -->
  <!-- ============================================================== -->
  <div class="container">
    <aside class="left-sidebar">
      <ul class="nav-bar navbar-inverse">
        <li class="nav-item"> <a class="nav-link navbar-toggler sidebartoggler hidden-sm-down waves-effect waves-dark float-right" href="javascript:void(0)"><span class="navbar-toggler-icon"></span></a> </li>
      </ul>
      <!-- Sidebar scroll-->
      <div class="scroll-sidebar">
        <!-- Sidebar navigation-->
        <nav class="sidebar-nav">
          <ul id="sidebarnav">
            <li class="clearfix"></li>
            <li> <a class="has-arrow waves-effect waves-dark" href="#" aria-expanded="false"><i class="flaticon-desktop-computer-screen-with-rising-graph"></i><span class="hide-menu">Dashboard</span></a>
              <ul aria-expanded="false" class="collapse">
                <li><a href="index.html">Server</a></li>
                <li><a href="index-projects.html">Project</a></li>
                <li><a href="index-analytics.html">Analytics</a></li>
                <li><a href="index-shop.html">Shop</a></li>
              </ul>
            </li>
            <li><a href="calendar.html"><i class="flaticon-calendar"></i><span class="hide-menu">Calendar</span></a></li>
            <li class="active"> <a class="has-arrow waves-effect waves-dark" href="#" aria-expanded="false"><i class="flaticon-restaurant"></i><span class="hide-menu">Ecommerce</span></a>
              <ul aria-expanded="false" class="collapse in">
                <li><a href="ecommerce-dashboard.html">Dashboard</a></li>
                <li><a href="ecommerce-pro-list.html">Product List</a></li>
                <li><a href="ecommerce-add-new.html">Add new product</a></li>
                <li><a href="ecommerce-orders.html">Orders</a></li>
                <li><a href="ecommerce-invoice.html">Invoice</a></li>
                <li><a href="ecommerce-customers.html">Customers</a></li>
              </ul>
            </li>
            <li><a href="email.html"><i class="flaticon-mail"></i> <span class="hide-menu">Mail</span></a></li>
            <li><a href="chats.html"><i class="flaticon-speech"></i><span class="hide-menu">Chat</span></a></li>
            <li><a href="to-do.html"><i class="flaticon-forms"></i><span class="hide-menu">To Do</span></a></li>
            <li><a href="change-log.html"><i class="flaticon-file"></i><span class="hide-menu">Change Log</span></a></li>
            <li> <a class="has-arrow waves-effect waves-dark" href="#" aria-expanded="false"><i class="flaticon-switch"></i><span class="hide-menu">UI Elements</span></a>
              <ul aria-expanded="false" class="collapse">
                <li><a href="ui-profile.html">Profile</a></li>
                <li><a href="ui-typography.html">Typography</a></li>
                <li><a href="ui-buttons.html">Buttons</a></li>
                <li><a href="ui-forms.html">Forms</a></li>
                <li><a href="ui-icons.html">Icons</a></li>
                <li><a href="ui-components.html">Components</a></li>
                <li><a href="ui-cards.html">Cards</a></li>
                <li><a href="ui-pricing-tables.html">Pricing tables</a></li>
                <li><a href="ui-timeline.html">Timeline</a></li>
                <li><a href="ui-charts.html">Charts</a></li>
                <li><a href="ui-tables.html">Tables</a></li>
              </ul>
            </li>
          </ul>
        </nav>
        <!-- End Sidebar navigation -->
      </div>
      <!-- End Sidebar scroll-->
    </aside>
    <!-- ============================================================== -->
    <!-- End Left Sidebar - style you can find in sidebar.scss  -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- Page wrapper  -->
    <!-- ============================================================== -->
    <div class="page-wrapper">
      <!-- ============================================================== -->
      <!-- Container fluid  -->
      <!-- ============================================================== -->
      <div class="container-fluid">
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Invoice box -->
        <!-- ============================================================== -->
        <div class="row">
          <!-- Column -->
          <div class="col-lg-12 col-md-12">
            <div class="card">
              <div class="card-body">
                <div class="row">
                  <div class="col-md-12">
                    <div class="card card-body printableArea">
                      <div class="row">
                        <div class="col-md-12 p-3">
                          <div class="pull-left">
                            <h3 class="text-center"> <span class="clearfix"></span> <span class="weight-600"> Reclamation</span></h3>
                          </div>
                        <div class="col-md-12">
                          <div class="table-responsive m-t-40">
<?PHP
include "reclamationC.php";
$reclamation1C=new ReclamationC();
$listeReclamations=$reclamation1C->afficherReclamations();

//var_dump($listeEmployes->fetchAll());
?>
<table border="1">
<tr>
<td>Name</td>
<td>Email</td>
<td>Subject</td>
<td>Message</td>
<td>supprimer</td>
<td>modifier</td>
</tr>

<?PHP
foreach($listeReclamations as $row){
  ?>
  <tr>
  <td><?PHP echo $row['name']; ?></td>
  <td><?PHP echo $row['email']; ?></td>
  <td><?PHP echo $row['subject']; ?></td>
  <td><?PHP echo $row['message']; ?></td>
  
  <td><form method="POST" action="supprimerReclamation.php">
  <input type="submit" name="supprimer" value="supprimer">
  <input type="hidden" value="<?PHP echo $row['name']; ?>" name="name">
  </form>
  </td>
  <td><a href="modifierReclamation.php?name=<?PHP echo $row['name']; ?>">
  Modifier</a></td>
  </tr>
  <?PHP
}
?>
</table>

          <!-- Column -->
        </div>
        <!-- ============================================================== -->
        <!-- End Invoice box -->
      </div>
    </div>
  </div>
  <!-- ============================================================== -->
  <!-- End Page Content -->
  <!-- ============================================================== -->
  <!-- ============================================================== -->
  <!-- End Container fluid  -->
  <!-- ============================================================== -->
  <!-- ============================================================== -->
  <!-- footer -->
  <!-- ============================================================== -->
  <!-- ============================================================== -->
  <!-- End footer -->
  <!-- ============================================================== -->
</div>
<!-- ============================================================== -->
<!-- End Page wrapper  -->
<!-- ============================================================== -->

<!-- ============================================================== -->
<!-- End Wrapper -->
<!-- ============================================================== -->
<!-- All Jquery -->
<!-- ============================================================== -->
<script src="plugins/vendors/jquery/jquery.min.js"></script>
<!-- Bootstrap popper Core JavaScript -->
<script src="plugins/vendors/bootstrap/js/popper.min.js"></script>
<script src="plugins/vendors/bootstrap/js/bootstrap.min.js"></script>
<!-- slimscrollbar scrollbar JavaScript -->
<script src="plugins/vendors/ps/perfect-scrollbar.jquery.min.js"></script>
<!--Wave Effects -->
<script src="assets/js/waves.js"></script>
<!--Menu sidebar -->
<script src="assets/js/sidebarmenu.js"></script>
<!--Custom JavaScript -->
<script src="assets/js/custom.min.js"></script>
<!-- ============================================================== -->
<!-- This page plugins -->
<!-- ============================================================== -->
<!-- Popup message jquery -->
<script src="plugins/vendors/toast-master/js/jquery.toast.js"></script>
<script src="assets/js/jquery.PrintArea.js" ></script>
<script>
   $(function() {
       $("#print").on('click', function() {
           var mode = 'iframe'; //popup
           var close = mode == "popup";
           var options = {
                mode: mode,
                popClose: close
           };
           $("div.printableArea").printArea(options);
       });
   });
</script>
<!-- ============================================================== -->
<!-- Style switcher -->
<!-- ============================================================== -->
<script src="plugins/vendors/styleswitcher/jQuery.style.switcher.js"></script>
</body>

<!-- Mirrored from jthemes.org/demo-admin/minton/ecommerce-invoice.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 28 Feb 2019 23:43:06 GMT -->
</html>
