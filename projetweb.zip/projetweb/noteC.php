<?PHP
include "config.php";
class NoteC {
function afficherNote ($note){
		echo "Idnote: ".$note->getidnote()."<br>";
		echo "Note: ".$note->getnote()."<br>";
		
	
	}
	
	function ajouterNote($note){
		$sql="insert into note (idnote,note) values (:idnote, :note)";
		$db = config::getConnexion();
		try{
        $req=$db->prepare($sql);
        $idnote=$note->getidnote();
        $note=$note->getnote();
       
		$req->bindValue(':idnote',$idnote);
		$req->bindValue(':note',$note);
		
	
		
            $req->execute();
           header("Location:noteredi.php");
exit();

        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
		
	}
	
	function afficherNotes(){
		//$sql="SElECT * From employe e inner join formationphp.employe a on e.cin= a.cin";
		$sql="SElECT * From note";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }	
	}
	function supprimerNote($idnote){
		$sql="DELETE FROM note where idnote= :idnote";
		$db = config::getConnexion();
        $req=$db->prepare($sql);
		$req->bindValue(':idnote',$idnote);
		try{
            $req->execute();
header("Location:noteadmin.php");
exit();
 }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	
	
	function modifierNote($note,$idnote){
		$sql="UPDATE note SET idnote=:idnotee, note=:notee WHERE idnote=:idnote";
		
		$db = config::getConnexion();
		//$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
try{		
        $req=$db->prepare($sql);
		$idnotee=$note->getidnote();
        $notee=$note->getnote();
        
		
        
		$datas = array(':idnotee'=>$idnotee, ':idnote'=>$idnote, ':notee'=>$notee);
		$req->bindValue(':idnotee',$idnotee);
		$req->bindValue(':idnote',$idnote);
		$req->bindValue(':notee',$notee);
	
		  
		
		
            $s=$req->execute();
			
           // header('Location: index.php');
        }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
   echo " Les datas : " ;
  print_r($datas);
        }
		
	}
	function recupererNote($idnote){
		$sql="SELECT * from note where idnote=$idnote";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	
	function rechercherListeNote($notee){
		$sql="SELECT * from note where note=$notee";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
}

?>