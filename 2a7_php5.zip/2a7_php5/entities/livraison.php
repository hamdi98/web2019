<?php


class livraison {

private $livId;
private $livdate;
private $email_lc;
private $modliv;
private $id_commande;



function __construct ($livId,$livdate,$email_lc,$modliv,$id_commande)
{

	$this->livId=$livId;
	$this->livdate=$livdate;
	$this->email_lc=$email_lc;
	$this->modliv=$modliv;
	$this->id_commande=$id_commande;
	
	




}
function getlivId(){return $this->livId;}
function getlivdate(){return $this->livdate;}
function getemail_lc(){return $this->email_lc;}
function getmodliv(){return $this->modliv;}
function getid_commande(){return $this->id_commande;}

/*function setnumero(){ $this->cin=$cin;}*/

}












?>