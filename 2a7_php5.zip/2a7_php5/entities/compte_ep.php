<?php
include "compte.php";

class compte_ep extends compte {

private $taux;


function __construct ($num,$solde,$taux)
{parent::__construct($num,$solde)

	$this->taux=$taux;
	
	




}
function gettaux(){return $this->$taux;}
function setsolde($taux){$this->taux=$taux;}




}












?>