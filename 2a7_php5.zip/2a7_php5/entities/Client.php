<?php 
class Client{
	private $namee;
	private $lname;
	private $pwd;
	private $rpwd;
	private $email;
	private $country;
	function __construct($namee,$lname,$pwd,$rpwd,$email,$country){
		$this->namee=$namee;
		$this->lname=$lname;
		$this->pwd=$pwd;
		$this->rpwd=$rpwd;
		$this->email=$email;
		$this->country=$country;
	}
	function getnamee(){
		return $this->namee;
	}
	function getlname(){
		return $this->lname;
	}
	function getpwd(){
		return $this->pwd;
	}
	function getrpwd(){
		return $this->rpwd;
	}
	function getemail(){
		return $this->email;
	}
	function getcountry(){
		return $this->country;
	}

	function setname($namee){
		$this->namee=$namee;
	}
	function setlname($lname){
		$this->lname=$lname;
	}
	function setpwd($pwd){
		$this->pwd=$pwd;
	}
	function setrpwd($rpwd){
		$this->rpwd=$rpwd;
	}
	function setemail($email){
		$this->email=$email;
	}
	function setcountry($country){
		$this->country=$country;
	}
    
}
 ?>