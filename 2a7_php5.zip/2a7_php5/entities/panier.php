<?php


class panier {

private $reference_pa;
private $quantite;
private $totale;
private $email_panier;



function __construct ($reference_pa,$quantite,$totale,$email_panier)
{

	$this->reference_pa=$reference_pa;
	$this->quantite=$quantite;
	$this->totale=$totale;
	$this->email_panier=$email_panier;



}
function getreference_pa(){return $this->reference_pa;}
function getquantite(){return $this->quantite;}
function gettotale(){return $this->totale;}
function getemail_panier(){return $this->email_panier;}


/*function setnumero(){ $this->cin=$cin;}*/

}












?>