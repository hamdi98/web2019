<?php 
class commande{
	private $id_co;
	private $id_panier;
	private $adresse;
	private $region;
	private $codepostale;
	private $numero;
	function __construct($id_co,$email_cli,$adresse,$region,$codepostale,$numero){
		$this->id_co=$id_co;
		$this->email_cli=$email_cli;
		$this->adresse=$adresse;
		$this->region=$region;
		$this->codepostale=$codepostale;
		$this->numero=$numero;
	}
	function getid_co(){
		return $this->id_co;
	}
	function getemail_cli(){
		return $this->email_cli;
	}
	function getadresse(){
		return $this->adresse;
	}
	function getregion(){
		return $this->region;
	}

function getcodepostale(){
		return $this->codepostale;
	}


	function getnumero(){
		return $this->numero;
	}
	
	
    
}
 ?>