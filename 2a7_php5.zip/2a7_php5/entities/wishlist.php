<?php

class wishlist {

private $reference_p;


function __construct ($reference_p,$email_c)
{

	$this->reference_p=$reference_p;
	$this->email_c=$email_c;



}
function getreference_p(){return $this->reference_p;}
function getemail_c(){return $this->email_c;}

/*function setnumero(){ $this->cin=$cin;}*/

}












?>