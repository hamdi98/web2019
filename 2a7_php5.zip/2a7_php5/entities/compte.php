<?php


class compte {

protected $num;
protected $solde;


function __construct ($num,$solde)
{

	$this->num=$num;
	$this->solde=$solde;
	




}
function getnum(){return $this->num;}
function getsolde(){return $this->solde;}
function setnum($num){ $this->num=$num;}
function setsolde($solde){$this->solde=$solde;}


/*function setnumero(){ $this->cin=$cin;}*/

}












?>