_<?php 
class Fidelity{
	private $email2;
	private $id;
	private $points;
	
	function __construct($email2,$id,$points){
		$this->email2=$email2;
		$this->id=$id;
		$this->points=$points;
	}
	function getemail2(){
		return $this->email2;
	}
	function getid(){
		return $this->id;
	}
	function getpoints(){
		return $this->points;
	}

	function setemail2($email2){
		$this->email2=$email2;
	}
	function setid($id){
		$this->id=$id;
	}
	function setpoints($points){
		$this->points=$points;
	}
    
}
 ?>