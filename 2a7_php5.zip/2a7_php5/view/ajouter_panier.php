<?php

include "../core/panierc.php";
include "../core/functions.php";
session_start();
if(logged_in())
{
 header("location:signup.php");
}


else if (isset($_GET['refprod']) && isset($_GET['quantite']) && isset($_GET['prixprod']) && isset($_GET['email_panier']) )
{
echo "fff";
$totale=0;
	$cin=$_GET['refprod'] ;
	$cin1=$_GET['quantite'] ;
	$cin2=$_GET['prixprod'] ;
	$cin3=$_GET['email_panier'] ;
	
	
			$totale=floatval($cin1) * floatval($cin2);
	
	/*if(!empty($_GET['reference_pa']) && !empty($_GET['quantite']) && !empty($_GET['prix']) )
	{*/

		$personne = new panier($cin,$cin1,$totale,$cin3 );
		$personnec = new panierc($cin,$cin1,$totale,$cin3);
		$msg=$personnec->ajouterpanier($personne);
		if ($msg==true)
		echo"ajout avec succes";
	header( 'Location:http://localhost/2a7_php5/view/cart.php');
	//else {echo "nope";}
	
//}
}
else
{
	echo "string";
}
?>