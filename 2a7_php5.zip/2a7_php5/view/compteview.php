<!DOCTYPE html>
<html>
<head>
	<title>atelier hritage</title>


</head>
<body>


	<?php

include "../core/comptec.php";
include "../entities/compte.php";


$compte= new compte("12","300");
$comptec=new comptec();
$res=$comptec->ajoutercompte($compte);
if ($res==true)
echo "add";
else 
echo "fail";
















	?>

</body>
</html>