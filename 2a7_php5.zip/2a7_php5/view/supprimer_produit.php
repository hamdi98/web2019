<?PHP
include "../core/produitC.php";
$ProduitC=new ProduitC();
if (isset($_POST["refprod"])){
$mess =$ProduitC->supprimerproduit($_POST["refprod"]);

header('Location:http://localhost/2a7_php5/view/page_afficher_produit_categorie.php');
}


?>