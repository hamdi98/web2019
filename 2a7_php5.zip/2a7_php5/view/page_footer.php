<page_footer>
    <table style="border-top: 1px solid #cce5ff width: 100%; background:  #cce5ff;">
        <tr>
            <td style="width: 100%; text-align: center;">
                <p>Mon adresse : 24 rue jordon , city jardin mornag , ben arous</p>
                <p>Tel 50 600 667</p>
            </td>
        </tr>
    </table>
</page_footer>
