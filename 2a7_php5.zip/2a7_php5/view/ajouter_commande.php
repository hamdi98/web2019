<?php

include "../core/commandec.php";
include "../core/livraisonc.php";

if (   isset($_GET['adresse']) &&  isset($_GET['email_cli'])  && isset($_GET['region'])  && isset($_GET['codepostale'])  && isset($_GET['numero']) && isset($_GET['livdate'])                &&   isset($_GET['email_lc']) && isset($_GET['modliv'])  )
{
echo "string";
function random_string1($length) {
    $key = '';
    $keys = array_merge(range(0, 9), range('a', 'z'));

    for ($i = 0; $i < $length; $i++) {
        $key .= $keys[array_rand($keys)];
    }

    return $key;
} 
	

		function random_string($length) {
    $key = '';
    $keys = array_merge(range(0, 9), range('a', 'z'));

    for ($i = 0; $i < $length; $i++) {
        $key .= $keys[array_rand($keys)];
    }

    return $key;
} 



	$nom2=random_string1(9);
	$prenom2=$_GET['email_cli'] ;
	$numero2=$_GET['adresse'] ;
	$nom1=$_GET['region'] ;
	$prenom1=$_GET['codepostale'] ;
	$numero1=$_GET['numero'] ;

	/*if( !empty($_GET['id_co']) &&! empty($_GET['id_panier']) && !empty($_GET['adresse'])  )
	{*/

		$commande =  new commande($nom2,$prenom2,$numero2,$nom1,$prenom1,$numero1);
		$commandec = new  commandec($nom2,$prenom2,$numero2,$nom1,$prenom1,$numero1);
		$msg=$commandec-> ajoutercommande($commande);

		

	
	$Id=random_string(9);     
	$nom=$_GET['livdate'] ;
	$prenom=$_GET['email_lc'] ;
	$numero=$_GET['modliv'] ;

	/*if( !empty($_GET['livdate']) &&! empty($_GET['email_lc']) && !empty($_GET['modliv'])  )
	{*/

		$livreure =  new livraison($Id,$nom,$prenom,$numero,$nom2);
		$livreurec = new  livraisonc($Id,$nom,$prenom,$numero,$nom2);
		$msg1=$livreurec-> ajouterlivraison($livreure);

		if ($msg==true)
		echo"ajout avec succes";
	else 
		echo "nah";
		//header( 'Location: http://localhost/2a7_php5/view/checkout.php');
		if ($msg1==true)
		echo"ajout avec succes";
	else 
		echo "nah";

//}
}





/*if ( isset($_GET['livdate'])&&isset($_GET['email_lc']) && isset($_GET['modliv']) )
{

function random_string($length) {
    $key = '';
    $keys = array_merge(range(0, 9), range('a', 'z'));

    for ($i = 0; $i < $length; $i++) {
        $key .= $keys[array_rand($keys)];
    }

    return $key;
} 
	
	$Id=random_string(9);     
	$nom=$_GET['livdate'] ;
	$prenom=$_GET['email_lc'] ;
	$numero=$_GET['modliv'] ;

	if( !empty($_GET['livdate']) &&! empty($_GET['email_lc']) && !empty($_GET['modliv'])  )
	{

		$livreure =  new livraison($Id,$nom,$prenom,$numero);
		$livreurec = new  livraisonc($Id,$nom,$prenom,$numero);
		$msg=$livreurec-> ajouterlivraison($livreure);

		
		if ($msg==true)
		echo"ajout avec succes";
	else 
		echo "nah";
		//header( 'Location: http://localhost/2a7_php5/view/checkout.php');
		

}
}*/

?>
