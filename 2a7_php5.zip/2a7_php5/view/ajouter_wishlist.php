<?php

include "../core/wishlistc.php";
include "../core/functions.php";
session_start();
if(logged_in())
{
 header("location:signup.php");
}
else if (isset($_GET['reference']) && isset($_GET['email_c']))
{


	$cin=$_GET['reference'] ;
	$cin1=$_GET['email_c'] ;
	
	if(!empty($_GET['reference']) && !empty($_GET['email_c']) )
	{
		$personne = new wishlist($cin,$cin1 );
		$personnec = new wishlistc($cin,$cin1);
		$msg=$personnec->ajouterrefe($personne);
		if ($msg==true)
		echo"ajout avec succes";
	header( 'Location:http://localhost/2a7_php5/view/afficher_wishlist.php');
	
}
}

?>