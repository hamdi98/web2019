<page_header>
    <table class="table-header">
        <tr>
            <td class="logo">
                <img src="logo2.JPG" style="height: 80px; width: 100px;" />
                
            </td>
            <td class="company-head"><h3>D'ART DESGIN STORE</h3></td>
        </tr>
    </table>
</page_header>
