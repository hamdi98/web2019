<page_footer>
    <table style="border-top: 1px solid #666666; width: 100%; background: #cccccc;">
        <tr>
            <td style="width: 100%; text-align: center;">
                <p>My Company Address 44545,  Patente 4555 </p>
                <p>Tel 45454545454, FAX 454545457578 </p>
            </td>
        </tr>
    </table>
</page_footer>
