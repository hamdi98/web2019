<page_header>
    <table class="table-header">
        <tr>
            <td class="logo">
                <img src="logo2.jpg" style="height: 80px; width: 100px;" />
                
            </td>
            <td class="company-head"><h3>D'art disgn store</h3></td>
        </tr>
    </table>
</page_header>
