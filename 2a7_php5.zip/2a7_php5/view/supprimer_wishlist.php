<?PHP
include "../core/wishlistc.php";
$livreurec=new wishlistc();
if (isset($_POST["reference_p"])){
	$livreurec->supprimerwishlist($_POST["reference_p"]);
	header('Location: http://localhost/2a7_php5/view/afficher_wishlist.php');
}

?>