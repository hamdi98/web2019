<?PHP
include "../core/CategorieC.php";
$CategorieC=new CategorieC();
if (isset($_POST["catprod"])){
$mess =$CategorieC->supprimercat($_POST["catprod"]);

header('Location:http://localhost/2a7_php5/view/tables-basic.php');
}


?>