<?php
include "../config.php";
include "../entities/livreure.php";
class livreurec{

	function  ajouter ($livreure)
	{
		try{
$sql="insert into livreure (Id,nom,prenom,numero,localisation)values (:Id,:nom,:prenom,:numero,:localisation)";
$db=config::getConnexion();
$req=$db->prepare ($sql);
$Id=$livreure->getId();
$nom=$livreure->getnom();
$prenom=$livreure->getprenom();
$numero=$livreure->getnumero();
$localisation=$livreure->getlocalisation();
$req->bindvalue(':Id',$Id);
$req->bindvalue(':nom',$nom);
$req->bindvalue(':prenom',$prenom);
$req->bindvalue(':numero',$numero);
$req->bindvalue(':localisation',$localisation);
$req->execute();
return true;
}
catch (Exception $e)
{echo 'Erreur' .$e->getMessage(); return false;



}
}
function afficherlivreure(){
		//$sql="SElECT * From employe e inner join formationphp.employe a on e.cin= a.cin";
		$sql="SElECT * From livreure";

		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }	
	}
function supprimerlivreure($Id){
		$sql="DELETE FROM livreure where Id= :Id";
		$db = config::getConnexion();
        $req=$db->prepare($sql);
		$req->bindValue(':Id',$Id);
		try{
            $req->execute();
           // header('Location: index.php');
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
}


function modifierlivreure($livreure,$Id){
		$sql="UPDATE livreure SET Id=:Idd, nom=:nom,prenom=:prenom,numero=:numero,localisation=:localisation WHERE Id=:Id";
		
		$db = config::getConnexion();
		//$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
try{		
        $req=$db->prepare($sql);
		$Idd=$livreure->getId();
        $nom=$livreure->getnom();
        $prenom=$livreure->getprenom();
        $numero=$livreure->getnumero();
        $localisation=$livreure->getlocalisation();
		$datas = array(':Idd'=>$Idd, ':Id'=>$Id, ':nom'=>$nom,':prenom'=>$prenom,':numero'=>$numero,':localisation'=>$localisation);
		$req->bindValue(':Idd',$Idd);
		$req->bindValue(':Id',$Id);
		$req->bindValue(':nom',$nom);
		$req->bindValue(':prenom',$prenom);
		$req->bindValue(':numero',$numero);
		$req->bindValue(':localisation',$localisation);
		
		
            $s=$req->execute();
			
           // header('Location: index.php');
        }
         catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
   echo " Les datas : " ;
  print_r($datas);
        }
		
	}
	function recupererlivreure($Id){
		$sql="SELECT * from livreure where Id='$Id' ";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
}



?>