<?php
include "../config.php";
include "../entities/compte.php";
class comptec{

	function  ajoutercompte ($compte)
	{
		try{
$sql="insert into livreure (num,solde)values (:num,:solde)";
$db=config::getConnexion();
$req=$db->prepare ($sql);
$Id=$livreure->getnum();
$nom=$livreure->getsolde();

$req->bindvalue(':num',$num);
$req->bindvalue(':solde',$solde);

$req->execute();
return true;
}
catch (Exception $e)
{echo 'Erreur' .$e->getMessage(); return false;



}
}
/*function afficherlivreure(){
		//$sql="SElECT * From employe e inner join formationphp.employe a on e.cin= a.cin";
		$sql="SElECT * From livreure";

		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }	
	}
function supprimerlivreure($Id){
		$sql="DELETE FROM livreure where Id= :Id";
		$db = config::getConnexion();
        $req=$db->prepare($sql);
		$req->bindValue(':Id',$Id);
		try{
            $req->execute();
           // header('Location: index.php');
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
}


function modifierlivreure($livreure,$Id){
		$sql="UPDATE livreure SET Id=:Idd, nom=:nom,prenom=:prenom,numero=:numero,localisation=:localisation WHERE Id=:Id";
		
		$db = config::getConnexion();
		//$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
try{		
        $req=$db->prepare($sql);
		$Idd=$livreure->getId();
        $nom=$livreure->getnom();
        $prenom=$livreure->getprenom();
        $numero=$livreure->getnumero();
        $localisation=$livreure->getlocalisation();
		$datas = array(':Idd'=>$Idd, ':Id'=>$Id, ':nom'=>$nom,':prenom'=>$prenom,':numero'=>$numero,':localisation'=>$localisation);
		$req->bindValue(':Idd',$Idd);
		$req->bindValue(':Id',$Id);
		$req->bindValue(':nom',$nom);
		$req->bindValue(':prenom',$prenom);
		$req->bindValue(':numero',$numero);
		$req->bindValue(':localisation',$localisation);
		
		
            $s=$req->execute();
			
           // header('Location: index.php');
        }
         catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
   echo " Les datas : " ;
  print_r($datas);
        }
		
	}
	function recupererlivreure($Id){
		$sql="SELECT * from livreure where Id='$Id' ";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}*/
}



?>