<?php
include "../config1.php";
include "../entities/livraison.php";
/*include "../entities/client.php";*/
class livraisonc{

	function  ajouterlivraison ($livraison)
	{
		try{
$sql="insert into livraison (livId,livdate,email_lc,modliv,id_commande)values (:livId,:livdate,:email_lc,:modliv,:id_commande)";
$db=config1::getConnexion();
$req=$db->prepare ($sql);

$reference=$livraison->getlivId();
$reference1=$livraison->getlivdate();
$email=$livraison->getemail_lc();
$email1=$livraison->getmodliv();
$email2=$livraison->getid_commande();




$req->bindvalue(':livId',$reference);
$req->bindvalue(':livdate',$reference1);
$req->bindvalue(':email_lc',$email);
$req->bindvalue(':modliv',$email1);
$req->bindvalue(':id_commande',$email2);



$req->execute();
return true;
}
catch (Exception $e)
{echo 'Erreur' .$e->getMessage(); return false;



}
}

function afficherlivraison(){
		$sql="SElECT * From livraison ";
		
		$db = config1::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }	
	}

function supprimerliv($livId){
		$sql="DELETE FROM livraison where livId=:livId";
		$db = config1::getConnexion();
        $req=$db->prepare($sql);
		$req->bindValue(':livId',$livId);
		try{
            $req->execute();
           // header('Location: index.php');
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
}
/*

function modifierlivreure($livreure,$Id){
		$sql="UPDATE livreure SET Id=:Idd, nom=:nom,prenom=:prenom,numero=:numero,localisation=:localisation WHERE Id=:Id";
		
		$db = config::getConnexion();
		//$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
try{		
        $req=$db->prepare($sql);
		$Idd=$livreure->getId();
        $nom=$livreure->getnom();
        $prenom=$livreure->getprenom();
        $numero=$livreure->getnumero();
        $localisation=$livreure->getlocalisation();
		$datas = array(':Idd'=>$Idd, ':Id'=>$Id, ':nom'=>$nom,':prenom'=>$prenom,':numero'=>$numero,':localisation'=>$localisation);
		$req->bindValue(':Idd',$Idd);
		$req->bindValue(':Id',$Id);
		$req->bindValue(':nom',$nom);
		$req->bindValue(':prenom',$prenom);
		$req->bindValue(':numero',$numero);
		$req->bindValue(':localisation',$localisation);
		
		
            $s=$req->execute();
			
           // header('Location: index.php');
        }
         catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
   echo " Les datas : " ;
  print_r($datas);
        }
		
	}
	function recupererlivreure($Id1){
		$sql="SELECT * from livreure where Id='z'";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}*/
}



?>