<?php
include "../config.php";
//include "../config.php";
include "../entities/panier.php";
include "../entities/produit.php";
class panierc{

	function  ajouterpanier ($panier)
	{
		try{
$sql="insert into panier (reference_pa,quantite,totale,email_panier)values (:reference_pa,:quantite,:totale,:email_panier)";
$db=config::getConnexion();
$req=$db->prepare ($sql);
$reference_pa=$panier->getreference_pa();
$quantite=$panier->getquantite();
$totale=$panier->gettotale();
$email_panier=$panier->getemail_panier();


$req->bindvalue(':reference_pa',$reference_pa);
$req->bindvalue(':quantite',$quantite);
$req->bindvalue(':totale',$totale);
$req->bindvalue(':email_panier',$email_panier);

$req->execute();
return true;
}
catch (Exception $e)
{echo 'Erreur' .$e->getMessage(); return false;



}
}
function afficherpanier($emaill){
		$sql="SElECT * From produit e inner join panier a on e.refprod= a.reference_pa where a.email_panier='".$emaill."' " ;
	
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);

		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
        try{
		$liste2=$db->query($sql2);
		
		return $liste2;
		}
        catch (Exception $s){
            die('Erreur: '.$s->getMessage());
        }		
	}
	/*function afficherwishlist2(){
		$sql="SElECT * From wishlist";
		
		$db = config3::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }	
	}*/
function supprimerpanier($reference_pa){
		$sql="DELETE FROM panier where reference_pa=:reference_pa";
		$db = config::getConnexion();
        $req=$db->prepare($sql);
		$req->bindValue(':reference_pa',$reference_pa);
		try{
            $req->execute();
           // header('Location: index.php');
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
}


function modifierpanier($panier,$emaill){
		$sql="UPDATE panier SET reference_pa=:Idd, quantite=:nom,totale=:prenom,email_panier=:numero WHERE emaill=:emaill";
		
		$db = config::getConnexion();
		//$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
try{		
        $req=$db->prepare($sql);

		$Idd=$panier->getreference_pa();
        $nom=$panier->getquantite();
        $prenom=$panier->gettotale();
        $numero=$panier->getemail_panier();
      
		$datas = array(':reference_pa'=>$Idd ,':quantite'=>$nom, ':totale'=>$prenom , ':email_panier'=>$numero,':emaill'=>$emaill);
		
		$req->bindValue(':reference_pa',$Idd);
		$req->bindValue(':quantite',$nom);
		$req->bindValue('totale:',$prenom);
		$req->bindValue(':email_panier',$numero);
			$req->bindValue(':emaill',$emaill);
	
		
		
            $s=$req->execute();
			
           // header('Location: index.php');
        }
         catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
   echo " Les datas : " ;
  print_r($datas);
        }
		
	}
	/*function recupererlivreure($Id1){
		$sql="SELECT * from livreure where Id='z'";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}*/
}



?>