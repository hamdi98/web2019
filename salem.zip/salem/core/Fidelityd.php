<?php 
include "../config5.php";


class Fidelityd{

        function afficherFidelity ($Fidelity){
		echo "name : ".$Fidelity->getemail2()."<br>";
		echo "last name: ".$Fidelity->getid()."<br>";
		echo "password: ".$Fidelity->getpoints()."<br>";
	}
		function afficherFidelitys(){
		//$sql="SElECT * From employe e inner join formationphp.employe a on e.cin= a.cin";
		$sql="SElECT * From fidelitycard";
		$db = config5::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }	
	}
	function ajoutercard($Fidelity){

		$sql="insert into fidelitycard (email2,id,points) values (:email2,:id,:points)";
		$db = config5::getConnexion();
		try{
        $req=$db->prepare($sql);
		
        $email2=$Fidelity->getemail2();
        $id=$Fidelity->getid();
        $points=$Fidelity->getpoints();
		$req->bindValue(':email2',$email2);
		$req->bindValue('id',$id);
		$req->bindValue(':points',$points);
		
            $req->execute();
           
        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }

}
	function supprimerCard($email2){
		$sql="DELETE FROM fidelitycard where email2= :email2";
		$db = config5::getConnexion();
        $req=$db->prepare($sql);
		$req->bindValue(':email2',$email2);
		try{
            $req->execute();
           // header('Location: index.php');
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}

	function modifierCard($Fidelity,$email2){
		$sql="UPDATE fidelitycard SET email2=:email2,email2=:eemail2,id=:id,points=:points WHERE email2=:email2 ";
		
		$db = config5::getConnexion();
		//$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
try{		
        $req=$db->prepare($sql);

        $eemail2=$Fidelity->getemail2();
        $id=$Fidelity->getid();
        $points=$Fidelity->getpoints();
		$datas = array(':email2'=>$email2,':eemail2'=>$email2,':id'=>$id,':points'=>$points);

        $req->bindValue(':email2',$email2);	
        $req->bindValue(':eemail2',$email2);	
        $req->bindValue(':id',$id);
		$req->bindValue(':points',$points);

		
		
            $s=$req->execute();
			
           // header('Location: index.php');
        }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
   echo " Les datas : " ;
  print_r($datas);
        }
		
	}

}

?>