<?php 
include "../config4.php";
class Clientd{

    function afficherclient ($client){
		echo "name : ".$client->getnamee()."<br>";
		echo "last name: ".$client->getlname()."<br>";
		echo "password: ".$client->getPrenom()."<br>";
		echo "r password: ".$client->getTarifHoraire()."<br>";
		echo "email: ".$client->getNbHeures()."<br>";
		echo "country: ".$client->getNbHeures()."<br>";
	}
		function afficherclients(){
		//$sql="SElECT * From employe e inner join formationphp.employe a on e.cin= a.cin";
		$sql="SElECT * From client";
		$db = config4::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }	
	}

	function ajouterclient($client){
		$sql="insert into client (namee,lname,pwd,rpwd,email,country) values (:namee,:lname,:pwd,:rpwd,:email,:country)";
		$db = config4::getConnexion();
		try{
        $req=$db->prepare($sql);
		
        $namee=$client->getnamee();
        $lname=$client->getlname();
        $pwd=$client->getpwd();
        $rpwd=$client->getrpwd();
        $email=$client->getemail();
        $country=$client->getcountry();
		$req->bindValue(':namee',$namee);
		$req->bindValue(':lname',$lname);
		$req->bindValue(':pwd',$pwd);
		$req->bindValue(':rpwd',$rpwd);
		$req->bindValue(':email',$email);
		$req->bindValue(':country',$country);
		
		
            $req->execute();
           
        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
		
	}

function modifierClient($client,$email){
		$sql="UPDATE client SET namee=:namee,lname=:lname,pwd=:pwd,rpwd=:rpwd,country=:country,email=:email,email=:eemail WHERE email=:email ";
		
		$db = config4::getConnexion();
		//$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
try{		
        $req=$db->prepare($sql);
        $namee=$client->getnamee();
        $lname=$client->getlname();
        $pwd=$client->getpwd();
        $rpwd=$client->getrpwd();
        $country=$client->getcountry();
        $eemail=$client->getemail();
		$datas = array(':namee'=>$namee,':lname'=>$lname,':pwd'=>$pwd,':rpwd'=>$rpwd,':country'=>$country,':eemail'=>$email,':email'=>$email);
		
        $req->bindValue(':namee',$namee);
		$req->bindValue(':lname',$lname);
		$req->bindValue(':pwd',$pwd);
		$req->bindValue(':rpwd',$rpwd);
		$req->bindValue(':country',$country);
		$req->bindValue(':eemail',$email);
		$req->bindValue(':email',$email);
		
		
            $s=$req->execute();
			
           // header('Location: index.php');
        }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
   echo " Les datas : " ;
  print_r($datas);
        }
		
	}
		function recupererClient($emaill){
		$sql="SELECT * from client where email=$emaill";
		$db = config4::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	function supprimerClient($email){
		$sql="DELETE FROM client where email= :email";
		$db = config4::getConnexion();
        $req=$db->prepare($sql);
		$req->bindValue(':email',$email);
		try{
            $req->execute();
           // header('Location: index.php');
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
}

 ?>