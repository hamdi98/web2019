<?php
include "../config3.php";
//include "../config.php";
include "../entities/wishlist.php";
include "../entities/produit.php";
class wishlistc{

	function  ajouterrefe ($wishlist)
	{
		try{
$sql="insert into wishlist (reference_p,email_c)values (:reference_p,:email_c)";
$db=config3::getConnexion();
$req=$db->prepare ($sql);
$reference_p=$wishlist->getreference_p();
$email_c=$wishlist->getemail_c();


$req->bindvalue(':reference_p',$reference_p);
$req->bindvalue(':email_c',$email_c);


$req->execute();
return true;
}
catch (Exception $e)
{echo 'Erreur' .$e->getMessage(); return false;



}
}

function afficherwishlist($emaill){
		$sql="SElECT * From  produit e inner join  wishlist a on e.refprod= a.reference_p where a.email_c='".$emaill."' ";  //
		
		$db = config3::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }	
	}
	function afficherwishlist2(){
		$sql="SElECT * From wishlist";
		
		$db = config3::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }	
	}
function supprimerwishlist($reference_p){
		$sql="DELETE FROM wishlist where reference_p=:reference_p";
		$db = config3::getConnexion();
        $req=$db->prepare($sql);
		$req->bindValue(':reference_p',$reference_p);
		try{
            $req->execute();
           // header('Location: index.php');
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
}
/*

function modifierlivreure($livreure,$Id){
		$sql="UPDATE livreure SET Id=:Idd, nom=:nom,prenom=:prenom,numero=:numero,localisation=:localisation WHERE Id=:Id";
		
		$db = config::getConnexion();
		//$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
try{		
        $req=$db->prepare($sql);
		$Idd=$livreure->getId();
        $nom=$livreure->getnom();
        $prenom=$livreure->getprenom();
        $numero=$livreure->getnumero();
        $localisation=$livreure->getlocalisation();
		$datas = array(':Idd'=>$Idd, ':Id'=>$Id, ':nom'=>$nom,':prenom'=>$prenom,':numero'=>$numero,':localisation'=>$localisation);
		$req->bindValue(':Idd',$Idd);
		$req->bindValue(':Id',$Id);
		$req->bindValue(':nom',$nom);
		$req->bindValue(':prenom',$prenom);
		$req->bindValue(':numero',$numero);
		$req->bindValue(':localisation',$localisation);
		
		
            $s=$req->execute();
			
           // header('Location: index.php');
        }
         catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
   echo " Les datas : " ;
  print_r($datas);
        }
		
	}
	function recupererlivreure($Id1){
		$sql="SELECT * from livreure where Id='z'";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}*/
}



?>