<?php

class livreure {

protected $Id;
private $nom;
private $prenom;
private $numero;
private $localisation;

function __construct ($Id,$nom,$prenom,$numero,$localisation)
{

	$this->Id=$Id;
$this->nom=$nom;
$this->prenom=$prenom;
$this->numero=$numero;
$this->localisation=$localisation;
}
function getId(){return $this->Id;}
function getnom(){return $this->nom;}
function getprenom(){return $this->prenom;}
function getnumero(){return $this->numero;}
function getlocalisation(){return $this->localisation;}
/*function setnumero(){ $this->cin=$cin;}*/

}












?>