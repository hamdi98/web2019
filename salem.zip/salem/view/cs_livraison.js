function test(){
alert("le champ Id est obligatoire");
var s1 = f.Id.value;
var nom= f.nom.value;
var prenom = f.prenom.value;
var numero = f.numero.value;
var localisation= f.localisation.value;

if( s1.length == 0 || nom.length== 0 /*&& !hasNumber(nom)*/ || prenom.length== 0  || numero.length== 0   || localisation.length== 0)
{
alert("tous les champs sont obligatoires!");
 /*returnToPreviousPage();
    return false;*/
}

}
else 
{
	alert("livreure enregistré!");
	 /*return true;*/
}
/*function hasNumber(myString) {
  return /\d/.test(myString);
}*/