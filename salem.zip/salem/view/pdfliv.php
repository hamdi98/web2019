<?php

include '../config1.php';
require_once('html2pdf/vendor/autoload.php');
$total=0;
    ?>
<link href="pdf-style.css" type="text/css" rel="stylesheet">
<page footer="date; page" backtop="20mm" backbottom="20mm" backleft="10mm" backright="10mm">
    <?php
        include 'page_header.php';
        include 'page_footer.php';
    ?>

    <h1>liste des  livreures</h1>
    <table class="doc-infos">
        <tr>
            <td class="invoice">
                <p>Date : 02/04/2019</p>
            </td>
            <td class="client">
                <h3>livreures</h3>
                
            </td>
        </tr>
    </table>
    <hr>

    <table class="doc-details" cellspacing="0">
        <tr>
            <th class="ref">ID </th>
            <th class="desig">nom</th>
            <th class="qte">prenom</th>
            <th class="price">numero</th>
            <th class="amount">localisation</th>
        </tr>

        <?php

          include "../core/livreurec.php";
$employe1C=new livreurec(); 
$listelproduit=$employe1C->afficherlivreure();
 
foreach($listelproduit as $row)
{
    ?>

    <tr>
   <td><?PHP echo $row['Id']; ?></td>
    <td><?PHP echo $row['nom']; ?></td>
    <td><?PHP echo $row['prenom']; ?></td>
    <td><?PHP echo $row['numero']; ?></td>
    <td><?PHP echo $row['localisation']; ?></td>
</tr>
<?php
}
           ?>

    </table>

    <br>
    <br>

   

    <br>
    <table class="signature-table" cellspacing="0">
        <tr>
            <td class="sinature"></td>
            <td class="amount-chars">
                <p>signature client</p>
            </td>
        </tr>
    </table>

 </page>
<?php


    $content = ob_get_clean();
    $lg = Array();
    $lg['a_meta_charset'] = 'UTF-8';
    $lg['a_meta_dir'] = 'rtl';
    $lg['a_meta_language'] = 'fa';
    $lg['w_page'] = 'page';

    // set some language-dependent strings (optional)

    $html2pdf = new HTML2PDF('P', 'A4', 'en');
    //$html2pdf->pdf->setLanguageArray($lg);

    $html2pdf->pdf->SetDisplayMode('fullpage');
    $html2pdf->writeHTML($content);
    $html2pdf->Output('livreures.pdf','D');




 ?>