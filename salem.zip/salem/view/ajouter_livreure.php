<?php

include "../core/livreurec.php";

function random_string($length) {
    $key = '';
    $keys = array_merge(range(0, 9), range('a', 'z'));

    for ($i = 0; $i < $length; $i++) {
        $key .= $keys[array_rand($keys)];
    }

    return $key;
} 
$Id=random_string(9);  
	$nom=$_GET['nom'] ;
	$prenom=$_GET['prenom'] ;
	$numero=$_GET['numero'] ;
	$localisation=$_GET['localisation'] ;
	
if (isset($_GET['prenom']) && isset($_GET['nom']) && isset($_GET['numero'])&& isset($_GET['localisation'])  && strpbrk($nom, '1234567890') == FALSE && strpbrk($prenom, '1234567890') == FALSE && strlen($numero)== 8 ) 
{



	
	if(  !empty($_GET['nom']) &&! empty($_GET['prenom']) && !empty($_GET['numero']) &&  !empty($_GET['localisation'])  )
	{
		$livreure =  new  livreure($Id,$nom,$prenom,$numero,$localisation);
		$livreurec = new  livreurec($Id,$nom,$prenom,$numero,$localisation);
		$msg=$livreurec->ajouter($livreure);
		
		if ($msg==true){
			header( 'Location: http://localhost/2a7_php5/view/tables-basic.php');
		}
		
	
	else if ($msg==false) {
	 	# code..
	  	header( 'Location: http://localhost/2a7_php5/view/ui-elements-modals.php');
		echo "verifier  que vos champs ne sont pas vide et correct";
	}
		
		

}
}


?>