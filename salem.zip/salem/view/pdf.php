<?php

include '../config1.php';
require_once('html2pdf/vendor/autoload.php');
$total=0;
    ?>
<link href="pdf-style.css" type="text/css" rel="stylesheet">
<page footer="date; page" backtop="20mm" backbottom="20mm" backleft="10mm" backright="10mm">
    <?php
        include 'page_header.php';
        include 'page_footer.php';
    ?>

    <h1>Facture</h1>
    <table class="doc-infos">
        <tr>
            <td class="invoice">
                <p>Date : 02/04/2019</p>
            </td>
            <td class="client">
                <h3>mes produits</h3>
                
            </td>
        </tr>
    </table>
    <hr>

    <table class="doc-details" cellspacing="0">
        <tr>
            <th class="ref">Reference </th>
            <th class="desig">nom</th>
            <th class="qte">prix</th>
            <th class="price">quantite</th>
            <th class="amount">code categorie</th>
        </tr>

        <?php

          include "../core/produitC.php";
$employe1C=new ProduitC(); 
$listelproduit=$employe1C->afficherproduit();
 
foreach($listelproduit as $row)
{
    ?>

    <tr>
    <td><?PHP echo $row['refprod']; ?></td>
    <td><?PHP echo $row['nomprod']; ?></td>
    <td><?PHP echo $row['prixprod']; ?></td>
    <td><?PHP echo $row['qteprod']; ?></td>
    <td><?PHP echo $row['catprod']; ?></td>
</tr>
<?php
}
           ?>

    </table>

    <br>
    <br>

   

    <br>
    <table class="signature-table" cellspacing="0">
        <tr>
            <td class="sinature"></td>
            <td class="amount-chars">
                <p>signature client</p>
            </td>
        </tr>
    </table>

 </page>
<?php


    $content = ob_get_clean();
    $lg = Array();
    $lg['a_meta_charset'] = 'UTF-8';
    $lg['a_meta_dir'] = 'rtl';
    $lg['a_meta_language'] = 'fa';
    $lg['w_page'] = 'page';

    // set some language-dependent strings (optional)

    $html2pdf = new HTML2PDF('P', 'A4', 'en');
    //$html2pdf->pdf->setLanguageArray($lg);

    $html2pdf->pdf->SetDisplayMode('fullpage');
    $html2pdf->writeHTML($content);
    $html2pdf->Output('fichierpdf.pdf','D');




 ?>