<?PHP
include "../core/Fidelityd.php";
$Fidelityd=new Fidelityd();
if (isset($_POST["email2"])){
	$Fidelityd->supprimerCard($_POST["email2"]);
	header("Refresh:0 url=tables-basic.php");
}

?>