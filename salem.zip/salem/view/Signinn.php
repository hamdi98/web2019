<?php 
include "../entities/Client.php";
include "../core/Clientd.php";

session_start();
$host="localhost";
$user="root";
$password="";
$db="2_a7 web";
 
$con = mysqli_connect($host,$user,$password,$db);

 
if(isset($_POST['email'])){
    
    $email=$_POST['email'];
    $pwd=$_POST['pwd'];
    


    $sqll="select * from fidelitycard where email2='".$email."' limit 1";
    
    $resultt=mysqli_query($con,$sqll);
       // if(!$resultt || mysqli_num_rows($resultt) == 1){
        //$_SESSION['mail']=$email;
        //header("location:homefidele.php");
        //exit();
    //}
    
    $sql="select * from client where email='".$email."'AND pwd='".$pwd."' limit 1";
    $_SESSION['mail']=$email;
    $result=mysqli_query($con,$sql);
    
    if(!$result || mysqli_num_rows($result) == 1){
        if(!$resultt || mysqli_num_rows($resultt) == 1){
       
        header("location:homefidele.php");} else{
        
        header("location:clienthome.php");
        exit();}
    }
    else{
        //echo " You Have Entered Incorrect Password";
        header("Location:Signin.php");
        exit();
    }
        
   }
?>