<?PHP
include "../core/livraisonc.php";
$livreurec=new livraisonc();
if (isset($_POST["livId"])){
	$livreurec->supprimerliv($_POST["livId"]);
	header('Location: http://localhost/2a7_php5/view/tables-basic.php');
}

?>