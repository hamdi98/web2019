<!DOCTYPE html>
<html lang="en">
<?php
include "../core/functions.php";
session_start();
if(logged_in())
{
 header("location:signup.php");
}


$host="localhost";
$user="root";
$password="";
$db="2_a7 web";
 
$con = mysqli_connect($host,$user,$password,$db);
$emaill=$_SESSION['mail'];

$result=mysqli_query($con , "SELECT namee,lname FROM client WHERE email='$emaill'");
$retrive=mysqli_fetch_array($result);
//print_r($retrive);
$name=$retrive['namee'];
$lname=$retrive['lname'];

$resulte=mysqli_query($con , "SELECT points,id FROM fidelitycard WHERE email2='$emaill'");
$retrivee=mysqli_fetch_array($resulte);
//print_r($retrive);
$pointss=$retrivee['points'];
$idd=$retrivee['id'];
$price=41;

?>
<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title  -->
    <title>Karl - Fashion Ecommerce Template | Cart</title>

    <!-- Favicon  -->
    <link rel="icon" href="img/core-img/favicon.ico">

    <!-- Core Style CSS -->
    <link rel="stylesheet" href="css/core-style.css">
    <link rel="stylesheet" href="style.css">

    <!-- Responsive CSS -->
    <link href="css/responsive.css" rel="stylesheet">

</head>

<body>
      <?php

                                 include "../core/panierc.php";
                                 $employe1C=new panierc(); 
                                      $listelivreure=$employe1C->afficherpanier($emaill);
                                        $listelivreure3=$employe1C->afficherpanier($emaill);
           
                                         ?>
    <div class="catagories-side-menu">
        <!-- Close Icon -->
        <div id="sideMenuClose">
            <i class="ti-close"></i>
        </div>
        <!--  Side Nav  -->
        <div class="nav-side-menu">
            <div class="menu-list">
                <h6>Categories</h6>
                <ul id="menu-content" class="menu-content collapse out">
                    <!-- Single Item -->
                    <li data-toggle="collapse" data-target="#women" class="collapsed active">
                        <a href="#">Woman wear <span class="arrow"></span></a>
                        <ul class="sub-menu collapse" id="women">
                            <li><a href="#">Midi Dresses</a></li>
                            <li><a href="#">Maxi Dresses</a></li>
                            <li><a href="#">Prom Dresses</a></li>
                            <li><a href="#">Little Black Dresses</a></li>
                            <li><a href="#">Mini Dresses</a></li>
                        </ul>
                    </li>
                    <!-- Single Item -->
                    <li data-toggle="collapse" data-target="#man" class="collapsed">
                        <a href="#">Man Wear <span class="arrow"></span></a>
                        <ul class="sub-menu collapse" id="man">
                            <li><a href="#">Man Dresses</a></li>
                            <li><a href="#">Man Black Dresses</a></li>
                            <li><a href="#">Man Mini Dresses</a></li>
                        </ul>
                    </li>
                    <!-- Single Item -->
                    <li data-toggle="collapse" data-target="#kids" class="collapsed">
                        <a href="#">Children <span class="arrow"></span></a>
                        <ul class="sub-menu collapse" id="kids">
                            <li><a href="#">Children Dresses</a></li>
                            <li><a href="#">Mini Dresses</a></li>
                        </ul>
                    </li>
                    <!-- Single Item -->
                    <li data-toggle="collapse" data-target="#bags" class="collapsed">
                        <a href="#">Bags &amp; Purses <span class="arrow"></span></a>
                        <ul class="sub-menu collapse" id="bags">
                            <li><a href="#">Bags</a></li>
                            <li><a href="#">Purses</a></li>
                        </ul>
                    </li>
                    <!-- Single Item -->
                    <li data-toggle="collapse" data-target="#eyewear" class="collapsed">
                        <a href="#">Eyewear <span class="arrow"></span></a>
                        <ul class="sub-menu collapse" id="eyewear">
                            <li><a href="#">Eyewear Style 1</a></li>
                            <li><a href="#">Eyewear Style 2</a></li>
                            <li><a href="#">Eyewear Style 3</a></li>
                        </ul>
                    </li>
                    <!-- Single Item -->
                    <li data-toggle="collapse" data-target="#footwear" class="collapsed">
                        <a href="#">Footwear <span class="arrow"></span></a>
                        <ul class="sub-menu collapse" id="footwear">
                            <li><a href="#">Footwear 1</a></li>
                            <li><a href="#">Footwear 2</a></li>
                            <li><a href="#">Footwear 3</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </div>

    <div id="wrapper">

        <!-- ****** Header Area Start ****** -->
        <header class="header_area bg-img background-overlay-white" style="background-image: url(file:///C|/Users/dell/Desktop/49864884_2372870216306233_5148569591990976512_n.jpg);">
            <!-- Top Header Area Start -->
            <div class="top_header_area">
                <div class="container h-100">
                    <div class="row h-100 align-items-center justify-content-end">

                        <div class="col-12 col-lg-7">
                            <div class="top_single_area d-flex align-items-center">
                                <!-- Logo Area -->
                                <div class="top_logo"> <a href="homefidele.php"><img src="d.jpg" height="183" width="187"></div></a>
                                 <div class="" style="position: absolute; right: 260px; bottom: 70px;" > <a href="http://localhost/2a7_php5/view/afficher_wishlist.php"><img src="heart.png"  width="30" height="30"></a></div>
                                <!-- Cart & Menu Area -->
                                <div class="header-cart-menu d-flex align-items-center ml-auto">
                                    <!-- Cart Area -->
                                    <div class="cart">
                                          <?php
                                      $s2=0;
                                        $s5=0;
                                        ?>
                                        
<?PHP  
foreach($listelivreure3 as $row3){
   
    ?>
                                        
                                       

                                         <?PHP
     
     $s2=$s2+$row3['quantite'];
       $s5=$s5+$row3['totale'];
     

}
?>
 <a href="#" id="header-cart-btn" target="_blank"><span class="cart_quantity"><?PHP echo $s2 ?></span> <i class="ti-bag"></i> Your Bag <?PHP echo $s5 ?>DT </a>
                                        <!-- Cart List Area Start -->
                                        <ul class="cart-list">
                                            <li>
                                                <a href="#" class="image"><img src="dd.png" class="cart-thumb" alt=""></a>
                                                <div class="cart-item-desc">
                                                    <h6><a href="#">decoration maison</a></h6>
                                                    <p>1x - <span class="price">20 dt</span></p>
                                                </div>
                                                <span class="dropdown-product-remove"><i class="icon-cross"></i></span>
                                            </li>
                                            <li>
                                                <a href="#" class="image"><img src="cc.png" class="cart-thumb" alt=""></a>
                                                <div class="cart-item-desc">
                                                    <h6><a href="#">elements salon</a></h6>
                                                    <p>1x - <span class="price">30 dt </span></p>
                                                </div>
                                                <span class="dropdown-product-remove"><i class="icon-cross"></i></span>
                                            </li>
                                            <li class="total">
                                             
                                                <a href="cart.php" class="btn btn-sm btn-cart">Cart</a>
                                                
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="header-right-side-menu ml-15">
                                        <a href="#" id="sideMenuBtn"><i class="ti-menu" aria-hidden="true"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

            <!-- Top Header Area End -->
            <div class="main_header_area">
                <div class="container h-100">
                    <div class="row h-100">
                        <div class="col-12 d-md-flex justify-content-between">
                            <!-- Header Social Area -->
                            <div class="header-social-area">
                                <a href="#"><span class="karl-level">Share</span> <i class="fa fa-instagram" aria-hidden="true"></i></a>
                                <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                                <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                                <a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
                            </div>
                            <!-- Menu Area -->
                            <div class="main-menu-area">
                                <nav class="navbar navbar-expand-lg align-items-start">

                                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#karl-navbar" aria-controls="karl-navbar" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"><i class="ti-menu"></i></span></button>

                                    <div class="collapse navbar-collapse align-items-start collapse" id="karl-navbar">
                                        <ul class="navbar-nav animated" id="nav">
                                            <li class="nav-item active"><a class="nav-link" href="homefidele.php">Accueil</a></li>
                                            <li class="nav-item dropdown">
                                                <a class="nav-link dropdown-toggle" href="#" id="karlDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Pages</a>
                                                <div class="dropdown-menu" aria-labelledby="karlDropdown">
                                                    <a class="dropdown-item" href="homefidele.php">accueil</a>
                                                    <a class="dropdown-item" href="shop.php">boutique</a>
                                                    
                                                    <a class="dropdown-item" href="cart.php">Cart</a>
                                                 
                                                </div>
                                            </li>
                                            <li class="nav-item"><a class="nav-link" href="#">salon</a></li>
                                            <li class="nav-item"><a class="nav-link" href="#">cuisine</a></li>
                                            <li class="nav-item"><a class="nav-link" href="#">Contact</a></li>
                                        </ul>
                                    </div>
                                </nav>
                            </div>
                            <!-- Help Line -->
                            <div class="help-line">
                                <a href="tel:+346573556778"><i class="ti-headphone-alt"></i> +34 657 3556 778</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- ****** Header Area End ****** -->

        <!-- ****** Top Discount Area Start ****** -->
      <section class="top-discount-area d-md-flex align-items-center">
        <!-- Single Discount Area --><!-- Single Discount Area --></section>
        <!-- ****** Top Discount Area End ****** -->

        <!-- ****** Cart Area Start ****** -->
      
        <div class="cart_area section_padding_100 clearfix">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="cart-table clearfix">
                            <table class="table table-responsive">
                                <thead>
                                    <tr>
                                        <th>Produit</th>
                                        <th>Prix</th>
                                        <th>Quantité</th>
                                        <th>Total</th>
                                         <th>delete</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                      
                                        <?php
                                      $s1=0;
                                        ?>
                                        
<?PHP  
foreach($listelivreure as $row){
   
    ?>
    <tr>
    <td><?PHP echo $row['nomprod']; ?></td>
    <td><?PHP echo $row['prixprod']; ?> DT </td>
    <td>   <form method="POST">
     <input type="number" name="quantite" src="mod.png" style="width: 30px;"  value="<?PHP echo $row['quantite']; ?>" > </td>
    <td><?PHP echo $row['totale']; ?> DT</td>
   
 <td>
    <input type="image"  src="cor.png" height="17" width="17"  data-toggle="modal" data-target="#quickview">  
   </td>
    

 <!--<a href="modifier_livreure?Id=<?PHP ; ?>"><input type="image" src="mod.png" height="17" width="17"  ></a> --> <!--data-toggle="modal" data-target="#quickview"-->
    
     <input type="hidden" name="email_panier"  value="<?PHP echo $emaill;?>">
     <input type="hidden" name="reference_pa" value="<?PHP echo $row['refprod']; ?>">
      <input type="hidden" name="totale" value="<?PHP echo $row['totale']; ?>">
       <input type="hidden" name="emaill"  value="<?PHP echo $emaill;?>">

    
          <input type="submit" name="modifier_panier" value="ok">
 </form>

    </tr>
    <?PHP
     
     $s1=$s1+$row['totale'];
}
?>
                                   
<?PHP
        
                        
                    if (
                        isset($_POST['modifier_panier'])){

                        $employe= new panier($_POST['reference_pa'],$_POST['quantite'],$_POST['totale'], $_POST['email_panier'] );
                        $employe1C->modifierpanier($employe,$_POST['emaill']);

                        
                     }

                        

                 ?> 


                                    </tr>
                                </tbody>
                            </table>
                        </div>



<!-- moda begin -->
 
 <div id="quickview" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
     <h3> confirmation</h3>
      </div>
      <div class="modal-body">
       <div class="randomdiv" >
 <p  style="position: absolute; left: 35px;"> voulez vous vraiment supprimez cette article(s) ?</p><br>
                             
          
                             <table >
                                <tr "><form method="POST" action="supprimer_panier.php">
                                           <input class="btn btn-default" type="submit"  name="supprimer" value="supprimer" style="position: absolute; left: 50px; bottom: 46px;" >
                                 <input type="hidden" value="<?PHP echo $row['reference_pa']; ?>" name="reference_pa" style="position: absolute; bottom: 12px;"> <br>
                  
                        
                          </form></tr>
                                <tr><button type="button" class="btn btn-default" id="btnclose" data-dismiss="modal">non</button></tr>
                                        

                         
                          
                         </table>

                     <div class="share_wf mt-30">

                                          

                                        </div>
                    
                          </div>
      </div>
      <div class="modal-footer">
          </div>
    </div>

  </div>
</div>

<!--modal end -->
<ul class="cart-total-chart">
                               
                                <li><span><strong>Total:<?PHP echo $s1 ?> DT </strong></span> <span><strong></strong></span></li>
                            </ul>

 <!-- ****** Checkout Area Start ****** -->
        <div class="checkout_area section_padding_100">
            <div class="container">
                <div class="row">

                    <div class="col-12 col-md-6">
                        <div class="checkout_details_area mt-50 clearfix">

                            <div class="cart-page-heading">
                                <h5>Billing Address</h5>
                                <p>Enter your cupone code</p>
                            </div>

                             <form  method="GET" name="f2" action="ajouter_commande.php" >
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="first_name">nom <span>*</span></label>
                                        <input type="text" class="form-control" id="first_name" value="<?PHP echo $name ?>" required  name="">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="last_name">prenom <span>*</span></label>
                                        <input type="text" class="form-control" id="last_name" value="<?PHP echo $lname ?>" name="" required>
                                    </div>
                                   
                                    <div class="col-12 mb-3">
                                        <label for="country">region <span>*</span></label>
                                        <select class="custom-select d-block w-100" id="country" name="region">
                                        <option value="ariana">ariana</option>
                                        <option value="tunis">tunis</option>
                                        <option value="ben arous">ben arous</option>
                                        <option value="kairouan">kairouan</option>
                                        <option value="gebes">gebes</option>
                                        <option value="beja">beja</option>
                                        <option value="bizert">bizert</option>
                                        <option value="kaf">kaf</option>
                                    </select>
                                    </div>
                                    <div class="col-12 mb-3">
                                        <label for="street_address">Address <span>*</span></label>
                                        <input type="text" class="form-control mb-3" id="street_address" value="" name="adresse">
                                        
                                    </div>
                                    <div class="col-12 mb-3">
                                        <label for="postcode">code postale <span>*</span></label>
                                        <input type="text" class="form-control" id="postcode" value="" name="codepostale">
                                    </div>
                                  
                                    <div class="col-12 mb-3">
                                        <label for="phone_number">numero <span>*</span></label>
                                        <input type="number" class="form-control" id="phone_number" min="0" value="" name="numero">
                                    </div>
                                    <div class="col-12 mb-4">
                                        <label for="email_address">Email  <span>*</span></label>
                                        <input type="email" class="form-control" id="email_address" value="<?PHP echo $emaill ?>">
                                    </div>

                                    <div class="col-12">
                                        <div class="custom-control custom-checkbox d-block mb-2">
                                            <input type="checkbox" class="custom-control-input" id="customCheck1" name="modliv" value="Livraison le lendemain">
                                            <label class="custom-control-label" for="customCheck1">Livraison le lendemain</label>
                                        </div>
                                        <div class="custom-control custom-checkbox d-block mb-2">
                                            <input type="checkbox" class="custom-control-input" id="customCheck2" name="modliv" value="Livraison standart">
                                            <label class="custom-control-label" for="customCheck2">Livraison standart</label>
                                        </div>
                                        <div class="custom-control custom-checkbox d-block">
                                            <input type="checkbox" class="custom-control-input" id="customCheck3" name="modliv" value="Ramassage personnel">
                                            <label class="custom-control-label" for="customCheck3">Ramassage personnel</label>
                                        </div>
                                    </div>
                                </div>
                          
                        </div>
                    </div>

                    <div class="col-12 col-md-6 col-lg-5 ml-lg-auto">
                        <div class="order-details-confirmation">

                            <div class="cart-page-heading">
                                <h5>Your Order</h5>
                                <p>The Details</p>
                            </div>

                            <ul class="order-details-form mb-4">
                                <li><span>Product</span> <span>Total</span></li>
                                <li><span>Cocktail Yellow dress</span> <span>$59.90</span></li>
                                <li><span>Subtotal</span> <span>$59.90</span></li>
                                <li><span>Shipping</span> <span>Free</span></li>
                                <li><span>Total</span> <span>$59.90</span></li>
                            </ul>

  <div id="accordion" role="tablist" class="mb-4">
                                <div class="card">
                                   

                                    <div id="collapseOne" class="collapse" role="tabpanel" aria-labelledby="headingOne" data-parent="#accordion">
                                        <div class="card-body">
                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin pharetra tempor so dales. Phasellus sagittis auctor gravida. Integ er bibendum sodales arcu id te mpus. Ut consectetur lacus.</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                   
                                </div>
                                <div class="card">
                                  
                                    <div id="collapseThree" class="collapse" role="tabpanel" aria-labelledby="headingThree" data-parent="#accordion">
                                       
                                    </div>
                                </div>
                                <div class="card">
                                  
                                    <div id="collapseFour" class="collapse show" role="tabpanel" aria-labelledby="headingThree" data-parent="#accordion">
                                        
                                    </div>
                                </div>
                           
                            </div>

                             <div>
                    
                                <?PHP
                                include "../entities/Fidelity.php";
                                 include "../core/Fidelityd.php";
                                 

                                 $Fidelityd=new Fidelityd();
                     
                                ?>
                          
                                <div class="row">

                                    <div class="col-md-6 mb-3">
                                        <input type="hidden" class="form-control" id="first_name" value="<?PHP echo $emaill ?>"  name="email2">

                                    </div>
                                    <div class="col-md-6 mb-3">

                                        <input type="hidden" class="form-control" id="last_name" value="<?PHP echo $idd ?>"  name="id">
                                    </div>
                                    <div class="col-12 mb-4">
                                        <input type="hidden" class="form-control" id="email_address" value="<?PHP echo $pointss=$pointss+$price ?>" name="points">
                                    </div>
                                    </div>
                                <div class="Change-button">
                                     <?php     
                          
                         

                          
                           $date=date("Y-m-d H:i:s");          ?>
         <button   id="submit-form-button" class="btn" type="submit" style="width: 400px; background-color: #ff084e;" >Place order </button>
         <input type="hidden" name="email_lc" value="<?PHP echo $emaill;?>">
         <input type="hidden" name="email_cli" value="<?PHP echo $emaill;?>">
             <input type="hidden" name="livdate" value="<?PHP echo $date;?>">
                    
                </div>
                            </form>
                            <?PHP
                        
                    if (isset($_POST['modifier'])){
                        $employe=new Fidelity($_POST['email2'],$_POST['id'],$_POST['points']);
                        $Fidelityd->modifierCard($employe,$_POST['email_ini']);
                        
                     }

                 ?> 
                </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <!-- ****** Checkout Area End ****** -->



        <!-- ****** Cart Area End ****** -->

        <!-- ****** Footer Area Start ****** -->
        <footer class="footer_area">
            <div class="container">
                <div class="row">
                    <!-- Single Footer Area Start -->
                    <div class="col-12 col-md-6 col-lg-3">
                        <div class="single_footer_area">
                            <div class="footer-logo">
                                <img src="img/core-img/logo.png" alt="">
                            </div>
                            <div class="copywrite_text d-flex align-items-center">
                                <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
                            </div>
                        </div>
                    </div>
                    <!-- Single Footer Area Start -->
                    <div class="col-12 col-sm-6 col-md-3 col-lg-2">
                        <div class="single_footer_area">
                            <ul class="footer_widget_menu">
                                <li><a href="#">About</a></li>
                                <li><a href="#">Blog</a></li>
                                <li><a href="#">Faq</a></li>
                                <li><a href="#">Returns</a></li>
                                <li><a href="#">Contact</a></li>
                            </ul>
                        </div>
                    </div>
                    <!-- Single Footer Area Start -->
                    <div class="col-12 col-sm-6 col-md-3 col-lg-2">
                        <div class="single_footer_area">
                            <ul class="footer_widget_menu">
                                <li><a href="#">My Account</a></li>
                                <li><a href="#">Shipping</a></li>
                                <li><a href="#">Our Policies</a></li>
                                <li><a href="#">Afiliates</a></li>
                            </ul>
                        </div>
                    </div>
                    <!-- Single Footer Area Start -->
                    <div class="col-12 col-lg-5">
                        <div class="single_footer_area">
                            <div class="footer_heading mb-30">
                                <h6>Subscribe to our newsletter</h6>
                            </div>
                            <div class="subscribtion_form">
                                <form action="#" method="post">
                                    <input type="email" name="mail" class="mail" placeholder="Your email here">
                                    <button type="submit" class="submit">Subscribe</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="line"></div>

                <!-- Footer Bottom Area Start -->
                <div class="footer_bottom_area">
                    <div class="row">
                        <div class="col-12">
                            <div class="footer_social_area text-center">
                                <a href="#"><i class="fa fa-pinterest" aria-hidden="true"></i></a>
                                <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                                <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                                <a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- ****** Footer Area End ****** -->
    </div>
    <!-- /.wrapper end -->

    <!-- jQuery (Necessary for All JavaScript Plugins) -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- Plugins js -->
    <script src="js/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>

</body>

</html>