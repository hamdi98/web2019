<?PHP
include "../core/Clientd.php";
$Clientd=new Clientd();
if (isset($_POST["email"])){
	$Clientd->supprimerClient($_POST["email"]);
	header("Refresh:0 url=tables-basic.php");
}

?>