<?php

include "../core/livraisonc.php";

if ( isset($_GET['livdate'])&&isset($_GET['email_lc']) && isset($_GET['modliv']) )
{

function random_string($length) {
    $key = '';
    $keys = array_merge(range(0, 9), range('a', 'z'));

    for ($i = 0; $i < $length; $i++) {
        $key .= $keys[array_rand($keys)];
    }

    return $key;
} 
	
	$Id=random_string(9);     
	$nom=$_GET['livdate'] ;
	$prenom=$_GET['email_lc'] ;
	$numero=$_GET['modliv'] ;

	if( !empty($_GET['livdate']) &&! empty($_GET['email_lc']) && !empty($_GET['modliv'])  )
	{

		$livreure =  new livraison($Id,$nom,$prenom,$numero);
		$livreurec = new  livraisonc($Id,$nom,$prenom,$numero);
		$msg=$livreurec-> ajouterlivraison($livreure);

		
		if ($msg==true)
		echo"ajout avec succes";
	else 
		echo "nah";
		header( 'Location: http://localhost/2a7_php5/view/checkout.php');
		

}
}

?>