<?PHP

include "../core/panierc.php";
$livreurec=new panierc();
if (isset($_POST["reference_pa"])){
	

	$livreurec->supprimerpanier($_POST["reference_pa"]);
	header('Location: http://localhost/2a7_php5/view/cart.php');
}

?>