# Octopus
Free Bootstrap admin dashboard

# Preview

### Screenshot

![Octopus admin dashboard template preview](https://colorlib.com/wp/wp-content/uploads/sites/2/octopus-free-creative-admin-dashboard.jpg)

### Demo Site: [Here](https://colorlib.com/polygon/octopus/index.html)

### Changelog
#### V 1.0.0
Initial Release
### Authors
[Colorlib](https://colorlib.com)

### More info
- [Bootstrap Admin Panels](https://colorlib.com/wp/free-bootstrap-admin-dashboard-templates/)
- [Angular dashboards](https://colorlib.com/wp/angularjs-admin-templates/)
- [Admin Panels](https://colorlib.com/wp/free-html5-admin-dashboard-templates/)
- [Bootstrap Templates](https://colorlib.com/wp/templates/)
- [Free WordPress Themes](https://colorlib.com/wp/free-wordpress-themes/)

### License

Octopus is licensed under The MIT License (MIT). Which means that you can use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the final products. But you always need to state that Colorlib is the original author of this template.
