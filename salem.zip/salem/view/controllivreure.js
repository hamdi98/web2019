function testlivv()
{
	alert("ecrivez votre nom");
	

	var Name=f.nom.value;
	var LName=f.prenom.value;
	var Password=f.numero.value;
	var RPassword=f.localisation.value;
	
	
   
	 if(Name.length==0   )
	{
		alert("ecrivez votre nom");
	}
	 else if(LName.length==0   )
	{
		alert("ecrivez votre prenom");
	}


	else if (Name.length>10 || LName.length>10)
	{
		alert("your name or last name is too long!");
	}
	else if (Password.length>8 || Password.length<8)
	{
		alert("le numero doit comprendre 8 chiffres");
	}
	
	 else if(RPassword.length==0   )
	{
		alert("ecrivez la localisation");
	}
	
	
}