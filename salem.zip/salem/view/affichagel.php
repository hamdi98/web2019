	
										
												<?PHP
include "../core/livreurec.php";

$employe1C=new livreurec(); 
$listelivreure=$employe1C->afficherlivreure();

//var_dump($listeEmployes->fetchAll());
?>
<table  >
<tr>
<td>Cin</td>
<td>Nom</td>
<td>Prenom</td>
<td>nb heures</td>
<td>tarif horaire</td>

</tr>

<?PHP
foreach($listelivreure as $row){
	?>
	<tr>
	<td><?PHP echo $row['Id']; ?></td>
	<td><?PHP echo $row['nom']; ?></td>
	<td><?PHP echo $row['prenom']; ?></td>
	<td><?PHP echo $row['numero']; ?></td>
	<td><?PHP echo $row['localisation']; ?></td>
	</tr>
	<?PHP
}
?>
</table>