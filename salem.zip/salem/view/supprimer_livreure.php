<?PHP
include "../core/livreurec.php";
$livreurec=new livreurec();
if (isset($_POST["Id"])){
	$livreurec->supprimerlivreure($_POST["Id"]);
	header('Location: http://localhost/2a7_php5/view/tables-basic.php');
}

?>