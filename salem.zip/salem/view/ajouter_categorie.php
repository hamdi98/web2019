<?php
include "../entities/Categorie.php";
include "../core/categorieC.php";

if (isset($_GET['idcat']) && isset($_GET['nomcat']) &&isset($_GET['discat']))
{

	$refprod=$_GET['idcat'];
	$nomprod=$_GET['nomcat'];
	$photo=$_GET['discat'] ;

	
	if(!empty($refprod)&& !empty($nomprod)&& !empty($photo) )
	{
		$Categories = new Categories($refprod ,$nomprod,$photo);
		$CategorieC = new CategorieC();
		//echo $Produit->getcatid();
		$mess=$CategorieC ->ajoutercat($Categories);
	if ($mess == true)

 header('Location: ajouter_categorie.php');
 	}
}
?>