  



  <?PHP
   include "../core/panierc.php";

                        
                    if (isset($_POST['modifier_panier'])){
                        $employe= new panier($_POST['reference_pa'],$_POST['quantite'],$_POST['totale'], $_POST['email_panier'] );
                        $panier->modifierpanier($employe,$_POST['emaill']);
                        
                     }

                 ?> 